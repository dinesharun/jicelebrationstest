-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 16, 2013 at 10:26 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jas15anniv`
--

-- --------------------------------------------------------

--
-- Table structure for table `eventinfo`
--

CREATE TABLE IF NOT EXISTS `eventinfo` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `ipaddr` text NOT NULL,
  `evtid` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  `groupname` text NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=156 ;

--
-- Dumping data for table `eventinfo`
--

INSERT INTO `eventinfo` (`no`, `name`, `ipaddr`, `evtid`, `groupid`, `groupname`) VALUES
(9, 'gokul', '', 0, 0, ''),
(36, 'asas', '', 2, 0, 'zsas'),
(37, 'awdasd', '', 2, 0, 'zsas'),
(38, 'dad', '', 2, 0, 'utyrfh'),
(45, 'Arun', '', 0, 0, ''),
(110, 'Dinesh Arun', '172.16.6.60', 1, 0, ''),
(125, 'kamal', '172.16.6.17', 0, 0, ''),
(126, 'kamal', '172.16.6.17', 1, 0, ''),
(127, 'kamal', '172.16.6.17', 2, 0, 'zzzzz'),
(128, 'kamal', '172.16.6.17', 3, 0, ''),
(130, 'kamal', '172.16.6.17', 5, 0, ''),
(131, 'kamal', '172.16.6.17', 7, 0, ''),
(132, 'kamal', '172.16.6.17', 8, 0, ''),
(137, 'raj', '', 2, 0, 'zzzzz'),
(152, 'dsf', '', 23, 0, 'sdf'),
(153, 'wr', '', 23, 0, 'sdf');

-- --------------------------------------------------------

--
-- Table structure for table `qod`
--

CREATE TABLE IF NOT EXISTS `qod` (
  `QID` int(11) NOT NULL,
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `ipaddr` text NOT NULL,
  `ans` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `qod`
--

INSERT INTO `qod` (`QID`, `no`, `name`, `ipaddr`, `ans`, `timestamp`) VALUES
(1, 1, 'Dinesh Arun', '172.16.6.60', 'answer', '2013-07-16 14:48:14');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE IF NOT EXISTS `userinfo` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `uname` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `email` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `level` int(11) NOT NULL DEFAULT '0',
  `ipaddr` text NOT NULL,
  PRIMARY KEY (`no`),
  UNIQUE KEY `no` (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`no`, `uname`, `name`, `email`, `timestamp`, `level`, `ipaddr`) VALUES
(15, 'Kamalakkannan', 'kamal', 'kamalakkannan.r@jasmin-infotech.com', '2013-07-11 17:34:22', 0, '172.16.6.17'),
(21, 'Dinesharun', 'Dinesh Arun', 'dnsh.arun@gmail.com', '2013-07-12 09:53:42', 0, '172.16.6.60'),
(22, 'Dinesharun', 'Dinesh', 'dinesh.arun@rediffmail.com', '2013-07-15 09:19:54', 0, '127.0.0.1'),
(23, 'Gokul', 'Gokul', 'gokul.v@jasmin-infotech.com', '2013-07-15 18:02:32', 0, '172.16.6.115'),
(24, 'CELEBRATIONS', 'Celebrations', 'celebrations@jasmin-infotech.com', '2013-07-16 15:45:57', 0, '172.16.7.122');
